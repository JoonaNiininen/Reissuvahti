package com.example.reissuvahti;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class TripActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip);
/*
        LinearLayout Lil = findViewById(R.id.tripDestinationGrid);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);

        Button testGridButton = new Button(this);
        testGridButton.setText("Hankkija");
        View.OnClickListener l = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addLocation();
            }
        };

        Button testGridButton2 = new Button(this);
        testGridButton2.setText("AGCO");
        View.OnClickListener ll = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addLocation();
            }
        };
        testGridButton.setOnClickListener(ll);
        testGridButton2.setOnClickListener(l);
*/


    }
    public void testLocation(View v) {

    }

    public void addLocation(View view) {
        Button testButton = new Button(this);
        testButton.setText("lol");

        LinearLayout ll = (LinearLayout)findViewById(R.id.tripOverviewBar);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(120,120);
        ll.addView(testButton, lp);

        View.OnClickListener click = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeLocation(v);
            }
        };

        testButton.setOnClickListener(click);
    }

    public void removeLocation(View view) {
        LinearLayout ll = (LinearLayout)findViewById(R.id.tripOverviewBar);
        ll.removeView(view);
    }

    public void finishTrip(View view) {
        Intent finish = new Intent(this, MainActivity.class);
        startActivity(finish);

    }
}
